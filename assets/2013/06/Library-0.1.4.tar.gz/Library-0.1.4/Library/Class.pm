#
# Copyright (C) 2002 by Nicholas Dille <webmaster@rakshas.de>
#
# This file is part of Library.
#
# Library is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# Library is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with Library; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#

package Library::Class;

### PERL INTERNAL

use strict;
use warnings;
use English;
use UNIVERSAL qw(isa can);
use Carp;

### PUBLIC VARIABLES

our $VERSION = '1.1';

### METHODS

sub _new {
	my ($pkg) = @_;

	return bless {}, $pkg;
}

sub _construct {
	my $self = shift;
	my $isa = shift;

	foreach my $base (@$isa) {
		if (isa($base, 'Library::Class') and defined($base->can('new'))) {
			$self->_merge($base->new(@_));
		}
	}
}

sub _merge {
	my ($self, $base) = @_;

	if (not isa($base, 'HASH')) {
		confess('_merge(): ' . $base . ' is not a HASH reference.');
	}

	foreach my $key (keys %$base) {
		$self->{$key} = $base->{$key};
	}
}

1;

__END__

=head1 NAME

Library::Class - base class for objects

=head1 SYNOPSIS

require Library::Class
@ISA = (
	'Library::Class',
);

sub new {
	my ($pkg, $params) = @_;
	
	my $self = $pkg->_new();
	$self->_construct(\@ISA, $params);
}

=head1 DESCRIPTION

This modules provides a base class for perl objects.

=head1 INSTANCE VARIABLES

None.

=head1 CONSTRUCTOR

None.

=head1 PUBLIC METHODS

Although this module does not implements any public methods it expects that any base classes encountered in the $isa reference passed on to _construct() provide a constructor named new().

=head1 PRIVATE/PROTECTED METHODS

=over

=item _new($pkg)

This method returns a blessed HASH reference to create a common base for perl objects. It is no requirement to use this methodto initialize a blessed HASH reference.

=item _construct($self, $isa, ...)

All superclasses which are Library::Class subclasses are initializes by calling new() which is presumed to be the standard constructor. The result is expected to be a blessed HASH reference which contains the instance variables. This blessed reference is then passed on to _merge().

=item _merge($self, $base)

All instance variables contained in the blessed HASH reference $base are copied into the blessed HASH reference $self representing the current instance.

=back

=head1 AUTHOR

Nicholas Dille E<lt>webmaster@rakshas.deE<gt>

=cut
