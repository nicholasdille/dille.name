#
# Copyright (C) 2002 by Nicholas Dille <webmaster@rakshas.de>
#
# This file is part of Library.
#
# Library is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# Library is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with Library; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#

package Library::Code;

### PERL INTERNAL

use strict;
use warnings;
use English;
use UNIVERSAL qw(isa can);
use Carp;

### INHERITANCE

require Library::Class;
our @ISA = (
	'Library::Class',
);

### PUBLIC VARIABLES

our $VERSION = '1.0';

### PRIVATE VARIABLES

my $package = 'Library::Code';

### CONSTRUCTOR

sub new {
	my ($pkg, $params) = @_;

	my $self = bless {
		'active'	=> $params->{'active'},
		'code'		=> $params->{'code'},
	}, $pkg;
	$self->_construct(\@ISA, $params);

	return $self;
}

### INSTANCE METHODS

sub run {
	my ($self, @params) = @_;

	if (not defined($self->{'active'}) or not $self->{'active'}) {
		return;
	}

	my $code = $self->{'code'};
	my @return = &code(@params);

	if (@return) {
		return @return;
	}

	return;
}

1;

__END__

=head1 NAME

Library::Code - user code container

=head1 SYNOPSIS

use Library::Code;

my $code = Library::Code->new({'code' => sub {
	print 'user code' . "\n";
}});

=head1 DESCRIPTION

This modules provides a container for a code reference which can be executed without dereferencing it.

=head1 INSTANCE VARIABLES

=over

=item isActive

whether this code reference may be executed

=item code

the code reference

=back

=head1 CONSTRUCTOR

=over

=item $params

=over

=item code (compulsory)

This CODE reference will be wrapped in this class.

=item isActive (optional)

This boolean variable allows the execution to be switched on or off.

=back

=back

=head1 PUBLIC METHODS

=over

=item run(...)

This method executed the CODE reference contained in this class.

=back

=head1 PRIVATE/PROTECTED METHODS

None.

=head1 AUTHOR

Nicholas Dille E<lt>webmaster@rakshas.deE<gt>

=cut
