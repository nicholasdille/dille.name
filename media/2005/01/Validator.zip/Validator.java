import java.util.*;
import java.io.*;
import java.util.zip.*;
import java.net.*;
import org.xml.sax.helpers.*;
import org.xml.sax.*;

public class Validator {
	private static XMLReader parser;
	private static CachingEntityResolver cachingEntityResolver;

	public static void main(String[] args) {
		cachingEntityResolver = new CachingEntityResolver();

		try {
			parser = XMLReaderFactory.createXMLReader();
			parser.setFeature("http://xml.org/sax/features/namespaces", true);
			parser.setFeature("http://xml.org/sax/features/validation", true);
			parser.setFeature("http://apache.org/xml/features/validation/schema", true);
			parser.setFeature("http://apache.org/xml/features/validation/schema-full-checking", true);

		} catch (Exception e) {
			System.err.println("Exception: " + e);
			e.printStackTrace(new PrintStream(System.err));
			System.exit(1);
		}

		if (args.length == 0)
			cachingEntityResolver.showCache();
		
		else {
			for (int i = 0; i < args.length; ++i) {
				System.out.println("validating file \"" + args[i] + "\"");
				
				try {
					parser.setEntityResolver(cachingEntityResolver);
					parser.parse(new InputSource(new FileInputStream(args[i])));
		
				} catch (SAXParseException e) {
					System.err.println(args[i] + "(" + e.getLineNumber() + "," + e.getColumnNumber() + "): " + e.getMessage());
					System.exit(1);
		
				} catch (Exception e) {
					System.err.println("Exception: " + e);
					e.printStackTrace(new PrintStream(System.err));
					System.exit(1);
				}
			}
			cachingEntityResolver.storeCache();
		}
	}

}
