import java.io.*;
import org.xml.sax.*;

public class NullEntityResolver implements EntityResolver {

	public synchronized InputSource resolveEntity(String publicId, String systemId) {
		return new InputSource(new StringReader(""));
	}

}