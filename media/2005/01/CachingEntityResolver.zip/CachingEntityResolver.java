import java.util.*;
import java.io.*;
import java.util.zip.*;
import java.net.*;
import org.xml.sax.*;

public class CachingEntityResolver implements EntityResolver {
	private File cacheFile = new File("entity_cache");
	private HashMap<String,byte[]> cache;

	public CachingEntityResolver() {
		try {
			if (cacheFile.exists() && cacheFile.length() > 0) {
				ObjectInputStream inStream = new ObjectInputStream(new GZIPInputStream(new FileInputStream(cacheFile)));
				cache = (HashMap<String,byte[]>)inStream.readObject();
				inStream.close();
				
			} else
				cache = new HashMap<String,byte[]>();

		} catch (Exception e) {
			System.err.println("Exception: " + e);
			e.printStackTrace(new PrintStream(System.err));
			System.exit(1);
		}
	}

	public void showCache() {
		Iterator iterator = cache.keySet().iterator();
		while (iterator.hasNext()) {
			String key = (String)iterator.next();
			System.out.println(key);
		}
	}

	public void storeCache() {
		try {
			ObjectOutputStream outStream = new ObjectOutputStream(new GZIPOutputStream(new FileOutputStream(cacheFile)));
			outStream.writeObject(cache);
			outStream.close();

		} catch (Exception e) {
			System.err.println("Exception: " + e);
			e.printStackTrace(new PrintStream(System.err));
			System.exit(1);
		}
	}

	public synchronized InputSource resolveEntity(String publicId, String systemId) {
		InputSource result = new InputSource();
		result.setSystemId(systemId);
		result.setPublicId(publicId);
		byte[] document = (byte[])cache.get(publicId);
		if(document == null) {
			System.out.println("  retrieving \"" + publicId + "\"");
			try {
				URL url = new URL(systemId);
				InputStream is = url.openStream();

				ByteArrayOutputStream baos = new ByteArrayOutputStream();
				int read;
				byte[] buffer = new byte[1024];
				while((read = is .read(buffer)) > -1)
					baos.write(buffer, 0, read);
				document = baos.toByteArray();

				cache.put(publicId, document);

			} catch (Exception e) {
				System.err.println("Exception: " + e);
				e.printStackTrace(new PrintStream(System.err));
				System.exit(1);
			}
		}
		result.setByteStream(new ByteArrayInputStream(document));

		return result;
	}

}