[void] [System.Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms")
[void] [System.Reflection.Assembly]::LoadWithPartialName("System.Drawing") 

$objForm = New-Object System.Windows.Forms.Form 
$objForm.Text = "Choose VM to pause"
$objForm.Size = New-Object System.Drawing.Size(600,200) 
$objForm.StartPosition = "CenterScreen"

$objForm.KeyPreview = $True

$objForm.Add_KeyDown({
	if ($_.KeyCode -eq "Enter") {
		foreach ($objItem in $objListbox.SelectedItems) {
			$x += $objItem
		}
		$objForm.Close()
	}
})

$objForm.Add_KeyDown({
	if ($_.KeyCode -eq "Escape") {
		$objForm.Close()
	}
})

$PauseButton = New-Object System.Windows.Forms.Button
$PauseButton.Location = New-Object System.Drawing.Size(10,120)
$PauseButton.Size = New-Object System.Drawing.Size(75,23)
$PauseButton.Text = "Pause"
$PauseButton.Add_Click({
	foreach ($objItem in $objListbox.SelectedItems) {
		& "$Env:ProgramFiles\VMware\VMware VIX\VMrun.exe" pause "$objItem"
	}
})
$objForm.Controls.Add($PauseButton)

$UnpauseButton = New-Object System.Windows.Forms.Button
$UnpauseButton.Location = New-Object System.Drawing.Size(100,120)
$UnpauseButton.Size = New-Object System.Drawing.Size(75,23)
$UnpauseButton.Text = "Unpause"
$UnpauseButton.Add_Click({
	foreach ($objItem in $objListbox.SelectedItems) {
		& "$Env:ProgramFiles\VMware\VMware VIX\VMrun.exe" unpause "$objItem"
	}
})
$objForm.Controls.Add($UnpauseButton)

$CloseButton = New-Object System.Windows.Forms.Button
$CloseButton.Location = New-Object System.Drawing.Size(190,120)
$CloseButton.Size = New-Object System.Drawing.Size(75,23)
$CloseButton.Text = "Close"
$CloseButton.Add_Click({
	$objForm.Close()
})
$objForm.Controls.Add($CloseButton)

$objLabel = New-Object System.Windows.Forms.Label
$objLabel.Location = New-Object System.Drawing.Size(10,20) 
$objLabel.Size = New-Object System.Drawing.Size(280,20) 
$objLabel.Text = "Please make a selection from the list below:"
$objForm.Controls.Add($objLabel) 

$objListbox = New-Object System.Windows.Forms.Listbox 
$objListbox.Location = New-Object System.Drawing.Size(10,40) 
$objListbox.Size = New-Object System.Drawing.Size(560,20)

$objListbox.SelectionMode = "MultiExtended"

& "$Env:ProgramFiles\VMware\VMware VIX\VMrun.exe" list | Where-Object {$_.EndsWith(".vmx")} | ForEach-Object {[void] $objListbox.Items.Add($_)}

$objListbox.Height = 70
$objForm.Controls.Add($objListbox) 
$objForm.Topmost = $True

$objForm.Add_Shown({
	$objForm.Activate()
})
[void] $objForm.ShowDialog()
