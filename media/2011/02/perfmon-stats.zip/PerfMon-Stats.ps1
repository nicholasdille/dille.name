function Get-Metric(
    [string]$Object = "Processor",
    [string]$Counter = "% Processor Time",
    [string]$Instance = "_Total",
    [int]$DelayMs = 500
) {

	$objMetric = New-Object System.Diagnostics.PerformanceCounter($Object, $Counter, $Instance)

	While ($True) {
		$value = [math]::round($objMetric.NextValue(), 2)

		$now = [datetime]::now
		$year = $now.Year
		$month = $now.Month
		$day = $now.Day
		$hour = $now.Hour
		$minute = $now.Minute
		$second = $now.Second
		$milli = $now.Millisecond

		$date = "$year-"
		if ($month -lt 10) { $date = "$($date)0" }
		$date = "$date$($month)-"
		if ($day -lt 10) { $date = "$($date)0" }
		$date = "$date$($day)_"
		if ($hour -lt 10) { $date = "$($date)0" }
		$date = "$date$($hour):"
		if ($minute -lt 10) { $date = "$($date)0" }
		$date = "$date$($minute):"
		if ($second -lt 10) { $date = "$($date)0" }
		$date = "$date$($second)."
		if ($milli -lt 100) { $date = "$($date)0" }
		if ($milli -lt 10) { $date = "$($date)0" }
		$date = "$date$($milli)"

		"$date;$value"
  
		Start-Sleep -m $DelayMs
	}
}

function New-RingBuffer([int]$size) {
    $arrRing = @(0) * $size
    
    New-Object Object |
        Add-Member -MemberType NoteProperty -Name RingBuffer -Value $arrRing -PassThru |
        Add-Member -MemberType NoteProperty -Name CurrentItem -Value 0 -PassThru |
        Add-Member -MemberType NoteProperty -Name LastValue -Value 0 -PassThru |
        Add-Member -MemberType NoteProperty -Name Minimum -Value 0 -PassThru |
        Add-Member -MemberType NoteProperty -Name Maximum -Value 0 -PassThru |
        Add-Member -MemberType NoteProperty -Name Average -Value 0 -PassThru |
        Add-Member -MemberType NoteProperty -Name Deviation -Value 0 -PassThru |

        Add-Member -MemberType ScriptMethod -Name GetSize -Value {
            return $this.RingBuffer.Length
        } -PassThru |

        Add-Member -MemberType ScriptMethod -Name AddItem -Value {
            param([double]$item)
            
            $this.LastValue = $item
            
            $this.RingBuffer[$this.CurrentItem % $this.RingBuffer.Length] = $item
            
            ++$this.CurrentItem
            If ($this.CurrentItem -ge $this.RingBuffer.Length) {
                $this.CurrentItem = 0
                $this.GetAnalysis()
            }
        } -PassThru |

        Add-Member -MemberType ScriptMethod -Name GetRingBuffer -Value {
            return $this.RingBuffer
        } -PassThru |

        Add-Member -MemberType ScriptMethod -Name GetAnalysis -Value {
            $dblSum = 0
            $dblMin = $this.RingBuffer[0]
            $dblMax = $this.RingBuffer[0]
            $intIndex = 0
            $dblSumX = 0
            $dblSumX2 = 0
            $dblSumXY = 0
            $dblSumY = 0
            ForEach ($dblItem In $this.RingBuffer) {
                $dblSum += $dblItem

                If ($dblItem -lt $dblMin) { $dblMin = $dblItem }
                If ($dblItem -gt $dblMax) { $dblMax = $dblItem }
                
                $dblSumX += $intIndex
                $dblSumX2 += [math]::pow($intIndex, 2)
                $dblSumY += $dblItem
                $dblSumXY += $intIndex * $dblItem
                
                ++$intIndex
            }
            $this.Average = [math]::round($dblSum / $this.RingBuffer.Length, 2)
            $this.Minimum = $dblMin
            $this.Maximum = $dblMax
            
            $dblSum = 0
            ForEach ($dblItem In $this.RingBuffer) {
                $dblSum += [math]::pow($dblItem - $this.Average, 2)
            }
            $this.Deviation = [math]::round([math]::sqrt($dblSum / $this.RingBuffer.Length), 2)
        } -PassThru
}

function Get-Analysis(
	[int]$DelayMs = 500,
	[int]$Seconds = 60,
	[int]$Buckets = $($Seconds / $DelayMs * 1000),
	[bool]$ShowAll = $False,
	[bool]$csv = $False
) {

	Begin {
		$ring = New-RingBuffer($Buckets)

		$nValueCount = 0

		if ($csv) { "timestamp (YYYY-MM-DD_hh:mm:ss.mmm);value;min;avg;max;dev" }
	}

	Process {
		$strInput = [string]$_
    
		$aParams = $strInput.split(";")
		$sTimestamp = $aParams[0]
		$nValue = $aParams[1]

		++$nValueCount
    
		$ring.AddItem($nValue)
		$ring.GetAnalysis()

		if ($ShowAll -Or $nValueCount -gt $Buckets) {
    
			if ($csv) {
				"$sTimeStamp;$nValue;$($ring.Minimum);$($ring.Average);$($ring.Maximum)$($ring.Deviation)"
			} else {
				$ring
			}
		}
	}
}