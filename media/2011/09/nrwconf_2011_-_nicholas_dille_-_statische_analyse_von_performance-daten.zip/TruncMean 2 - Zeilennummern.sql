USE PerfMonDB

SELECT
	ROW_NUMBER() OVER(ORDER BY CounterDateTime DESC) AS RowNumber
	,COUNT(*) OVER() AS [RowCount]
	,*
FROM PerfMonData
ORDER By CounterDateTime DESC