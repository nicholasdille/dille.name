USE PerfMonDB

SELECT *
FROM (
	SELECT
		ROW_NUMBER() OVER(PARTITION BY MachineName, ObjectName, CounterName, InstanceName ORDER BY CounterDateTime DESC) AS RowNumber
		,COUNT(*) OVER(PARTITION BY MachineName, ObjectName, CounterName, InstanceName) AS [RowCount]
		,*
	FROM PerfMonData
) AS Numbered
WHERE Numbered.RowNumber > 1
AND Numbered.RowNumber < [RowCount] - 1