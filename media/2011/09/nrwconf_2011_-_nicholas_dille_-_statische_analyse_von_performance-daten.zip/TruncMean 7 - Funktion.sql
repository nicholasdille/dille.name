USE PerfMonDB
GO

CREATE FUNCTION PerfMonDataTruncated (
	@TruncPercent AS FLOAT = 0.1
)
RETURNS TABLE 
AS
RETURN 
(
	SELECT MachineName, ObjectName, CounterName, InstanceName, CounterDateTime, CounterValue
	FROM (
		SELECT
			ROW_NUMBER() OVER(PARTITION BY MachineName, ObjectName, CounterName, InstanceName ORDER BY CounterDateTime DESC) AS RowNumber
			,COUNT(*) OVER(PARTITION BY MachineName, ObjectName, CounterName, InstanceName) AS [RowCount]
			,MachineName, ObjectName, CounterName, InstanceName, CounterDateTime, CounterValue
		FROM PerfMonData
	) AS Numbered
	WHERE Numbered.RowNumber > @TruncPercent * [RowCount]
	AND Numbered.RowNumber < (1 - @TruncPercent) * [RowCount]
)