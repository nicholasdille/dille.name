USE PerfMonDB

SELECT
	MachineName
	, CounterName
	, MIN(CounterDateTime) AS StartTime
	, MAX(CounterDateTime) AS EndTime
	, SUM(CounterValue) AS ValueSum
	, COUNT(CounterValue) AS ValueCount
	, AVG(CounterValue) AS ValueAverage
FROM PerfMonData
WHERE CounterName LIKE '% Processor Time'
AND CounterDateTime BETWEEN '2011-09-07 00:00:00' AND '2011-09-08 00:00:00'
GROUP BY
	MachineName
	, ObjectName
	, CounterName
	, InstanceName