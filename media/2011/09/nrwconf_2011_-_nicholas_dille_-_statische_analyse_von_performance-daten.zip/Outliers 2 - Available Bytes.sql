USE PerfMonDB

SELECT MachineName, ObjectName, CounterName, InstanceName, AVG(CounterValue) AS AverageCounterValue, COUNT(CounterValue) AS ValueCount
FROM PerfMonData
WHERE CounterName LIKE 'Available Bytes'
AND MachineName LIKE '\\SRV1'
GROUP BY MachineName, ObjectName, CounterName, InstanceName

SELECT MachineName, ObjectName, CounterName, InstanceName, AVG(CounterValue) AS AverageCounterValue, COUNT(CounterValue) AS ValueCount
FROM (
	SELECT TOP(56) MachineName, ObjectName, CounterName, InstanceName, NULL AS CounterDateTime, 4294967296 AS CounterValue
	FROM PerfMonData
	WHERE CounterName LIKE 'Available Bytes'
	AND MachineName LIKE '\\SRV1'
	UNION ALL
	SELECT MachineName, ObjectName, CounterName, InstanceName, CounterDateTime, CounterValue
	FROM PerfMonData
	WHERE CounterName LIKE 'Available Bytes'
	AND MachineName LIKE '\\SRV1'
) As Numbered
GROUP BY MachineName, ObjectName, CounterName, InstanceName