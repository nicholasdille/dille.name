USE PerfMonDB

SELECT ROUND(CounterValue, -1) AS Bucket, COUNT(CounterValue) AS Count
FROM PerfMonData
WHERE MachineName LIKE '\\SRV1'
AND CounterName LIKE '% Processor Time'
GROUP BY ROUND(CounterValue, -1)
ORDER BY Bucket ASC