USE PerfMonDB

SELECT MachineName, ObjectName, CounterName, InstanceName, AVG(CounterValue) AS AverageCounterValue, COUNT(CounterValue) AS ValueCount
FROM PerfMonData
GROUP BY MachineName, ObjectName, CounterName, InstanceName

DECLARE @TruncPercent FLOAT
SET @TruncPercent = 0.1

SELECT MachineName, ObjectName, CounterName, InstanceName, AVG(CounterValue) AS AverageCounterValue, COUNT(CounterValue) AS ValueCount
FROM (
	SELECT
		ROW_NUMBER() OVER(PARTITION BY MachineName, ObjectName, CounterName, InstanceName ORDER BY CounterDateTime DESC) AS RowNumber
		,COUNT(*) OVER(PARTITION BY MachineName, ObjectName, CounterName, InstanceName) AS [RowCount]
		,MachineName, ObjectName, CounterName, InstanceName, CounterDateTime, CounterValue
	FROM PerfMonData
) AS Numbered
WHERE Numbered.RowNumber > @TruncPercent * [RowCount]
AND Numbered.RowNumber < (1 - @TruncPercent) * [RowCount]
GROUP BY MachineName, ObjectName, CounterName, InstanceName