USE PerfMonDB

SELECT
	ROW_NUMBER() OVER(PARTITION BY MachineName, ObjectName, CounterName, InstanceName ORDER BY CounterDateTime DESC) AS RowNumber
	,COUNT(*) OVER(PARTITION BY MachineName, ObjectName, CounterName, InstanceName) AS [RowCount]
	,*
FROM PerfMonData
ORDER BY MachineName, ObjectName, CounterName, InstanceName