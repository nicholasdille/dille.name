USE PerfMonDB
GO

CREATE VIEW Counters AS
	SELECT
		MachineName
		, ObjectName
		, CounterName
		, InstanceName
		, SUM(CounterValue) AS ValueSum
		, COUNT(CounterValue) AS ValueCount
		, AVG(CounterValue) AS ValueAverage
	FROM PerfMonData
	GROUP BY
		MachineName
		, ObjectName
		, CounterName
		, InstanceName