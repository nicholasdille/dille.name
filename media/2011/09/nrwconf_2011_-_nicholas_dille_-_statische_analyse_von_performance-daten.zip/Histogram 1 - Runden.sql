USE PerfMonDB

SELECT CounterDateTime, CounterValue, ROUND(CounterValue, -1)
FROM PerfMonData
WHERE MachineName LIKE '\\SRV1'
AND CounterName LIKE '% Processor Time'