USE PerfMonDB
GO

CREATE VIEW PerfMonData AS
	SELECT
		DisplayToID.DisplayString
		,DisplayToID.MinutesToUTC
		,CounterData.CounterDateTime
		,CounterDetails.MachineName
		,CounterDetails.ObjectName
		,CounterDetails.CounterName
		,CounterDetails.InstanceName
		,CounterData.CounterValue
	FROM CounterData
	INNER JOIN DisplayToID ON CounterData.GUID = DisplayToID.GUID
	INNER JOIN CounterDetails ON CounterData.CounterID = CounterDetails.CounterID