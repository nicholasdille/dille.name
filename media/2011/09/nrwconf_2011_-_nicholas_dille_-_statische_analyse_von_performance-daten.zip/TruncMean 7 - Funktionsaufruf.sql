USE PerfMonDB

SELECT * FROM PerfMonDataTruncated(DEFAULT)