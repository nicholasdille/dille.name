USE PerfMonDB

SELECT MachineName, ObjectName, CounterName, InstanceName, AVG(CounterValue) AS AverageCounterValue, COUNT(CounterValue) AS ValueCount
FROM PerfMonData
GROUP BY MachineName, ObjectName, CounterName, InstanceName
ORDER BY MachineName, ObjectName, CounterName, InstanceName