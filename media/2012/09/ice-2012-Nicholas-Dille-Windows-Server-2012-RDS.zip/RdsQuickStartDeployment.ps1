﻿Import-Module RemoteDesktop

# Define variables
$ConnectionBroker = "rds2.demo.local"
$WebAccessServer = "rds2.demo.local"
$SessionHost = "rds2.demo.local"
$CollectionName = "ice2012"

Get-Date

# Create new deployment
New-SessionDeployment `
    -ConnectionBroker $ConnectionBroker `    -WebAccessServer $WebAccessServer `    -SessionHost $SessionHost

# Create new session collection
New-RDSessionCollection `
    -ConnectionBroker $ConnectionBroker `    -CollectionName $CollectionName `    -CollectionDescription “Live demo at ice 2012” `    -SessionHost $SessionHost

# Create new RemoteApp
New-RDRemoteApp `
    –ConnectionBroker $ConnectionBroker `    -Alias Wordpad `    -DisplayName WordPad `    -FilePath "C:\Program Files\Windows NT\Accessories\wordpad.exe" `    -ShowInWebAccess 1 `    -CollectionName $CollectionName

# Add group to RemoteApp
Set-RDRemoteApp `    -ConnectionBroker $ConnectionBroker `    -CollectionName $CollectionName `    -Alias Wordpad `    -UserGroups "DEMO\Domain Users"Get-Date