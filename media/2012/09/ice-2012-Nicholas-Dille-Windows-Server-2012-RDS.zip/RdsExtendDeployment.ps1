﻿Import-Module RemoteDesktop

# Define variables
$ConnectionBroker = "rds1.demo.local"
$SessionHost = "rds2.demo.local"
$CollectionName = "ice2012"

Get-Date

# Add server to deployment
Add-RDServer `    -ConnectionBroker $ConnectionBroker `    -Server $SessionHost `    -role RDS-RD-SERVER# Create new session collectionNew-RDSessionCollection `    -ConnectionBroker $ConnectionBroker `    -CollectionName $CollectionName `    -SessionHost $SessionHost# Remove existing session host from collectionRemove-RDSessionHost `    -ConnectionBroker $ConnectionBroker `    -SessionHost $ConnectionBroker `    -Force# Add existing session host to collectionAdd-RDSessionHost `    -ConnectionBroker $ConnectionBroker `    -CollectionName $CollectionName `    -SessionHost $ConnectionBroker# Create new RemoteApp
New-RDRemoteApp `
    –ConnectionBroker $ConnectionBroker `    -CollectionName $CollectionName `    -Alias Wordpad `    -DisplayName WordPad `    -FilePath "C:\Program Files\Windows NT\Accessories\wordpad.exe"

# Add group to RemoteApp
Set-RDRemoteApp `    -ConnectionBroker $ConnectionBroker `    -CollectionName $CollectionName `    -Alias Wordpad `    -ShowInWebAccess $TrueGet-Date